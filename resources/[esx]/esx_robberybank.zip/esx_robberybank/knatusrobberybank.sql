INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('blowtorch', 'Soplete', 1, 0, 1),
('c4_bank', 'C4 de 10 kilos', 1, 0, 1),
('rasperry', 'Rasperry', 1, 0, 1);
