Locales ['en'] = {
  ['unlocked'] = '~g~Unlocked~s~',
  ['locked'] = '~r~Locked~s~',
  ['press_button'] = '[E] %s',
}